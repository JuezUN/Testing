class MyClass:
    def __init__(self):
        pass

    def say_hello(self, to_whom):
        print "Hello " + to_whom.get_name()
