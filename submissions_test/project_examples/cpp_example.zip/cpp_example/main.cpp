#include <iostream>
#include <vector>

using namespace std;

int main () {
  std::cout << "hello";
  vector<vector<int>> v;
}
